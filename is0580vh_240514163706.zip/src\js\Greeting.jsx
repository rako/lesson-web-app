/**
 * Reactコンポーネントの例
 */
// nameのデフォルト値を設定するようにしても構わない．
export const Greeting = ({ name }) => {
  /* ここから */
  return (
    <div>
      <p>こんにちは {name} さん</p>
    </div>
  )




  /* ここまで */
};
