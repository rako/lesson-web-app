/**
 * テキストチャット
 */
// CSSを使用する場合：CSSの定義の読み込み
/* ここから */

/* ここまで */
// reactから使用する関数をimportする．
/* ここから */

/* ここまで */

// 簡易ログイン機能を使用する．
import { LoginContext } from './Authenticate';
// Socket.IOのソケットを使用する．
import { SocketContext } from './WithSocket';

// TextChatコンポーネントの定義
export const TextChat = () => {
  // loginContextからユーザ情報を取得する．
  const user = useContext(LoginContext);
  const username = user ? user.username : '';
  // SocketContextからソケットを受け取る．
  const socketRef = useContext(SocketContext);
  const socket = socketRef ? socketRef.current : null;

  /* ここから */





  /* ここまで */

  return (
    /* CSSを使う時はclassName属性を追加してCSSクラスを設定してください．*/
    <div>
      {/* ここから */}





      {/* ここまで */}
    </div >
  );
}
