/**
 * ペイントチャット
 */
// reactから使用する関数をimportする．
/* ここから */

/* ここまで */

// 簡易ログイン機能を使用する．
import { LoginContext } from './Authenticate';
// Socket wrapperを使用する
import { SocketContext } from './WithSocket';

// ペイントを使用する．
import { Paint } from './Paint';

export const PaintChat = () => {
  // LoginContextからユーザ情報を取得する．
  const user = useContext(LoginContext);
  const username = user ? user.username : '';
  // SocketContextからソケットを受け取る．
  const socketRef = useContext(SocketContext);
  const socket = socketRef ? socketRef.current : null;

  /* ここから */





  /* ここまで */
};
