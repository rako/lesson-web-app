/**
 * テキストチャット
 */
// CSSを使用する場合：CSSの定義の読み込み
/* ここから */
//import '../css/ToDoList.css';
/* ここまで */
// reactから使用する関数をimportする．
/* ここから */
import { useState, useEffect, useContext } from 'react';
/* ここまで */

// 簡易ログイン機能を使用する．
import { LoginContext } from './Authenticate';
// Socket.IOのソケットを使用する．
import { SocketContext } from './WithSocket';

// TextChatコンポーネントの定義
export const TextChat = () => {
  // loginContextからユーザ情報を取得する．
  const user = useContext(LoginContext);
  const username = user ? user.username : '';
  // SocketContextからソケットを受け取る．
  const socketRef = useContext(SocketContext);
  const socket = socketRef ? socketRef.current : null;

  /* ここから */

  // 送信するテキストメッセージの入力
  const [inputMessage, setInputMessage] = useState('');
  // 受信したテキストメッセージのリスト
  const [messages, setMessages] = useState([]);

  // 受信したメッセージの処理
  const handleTextMessage = (data) => {
    // メッセージの最後に追加する．
    setMessages((prevMessages) => [...prevMessages, data]);
  };

  // チャットのメッセージの送信
  const sendTextMessage = () => {
    if (socket) {
      socket.emit('text', {
        from: username,
        to: '*'
        ,
        text: inputMessage,
      });
      // 入力エリアをクリアする．
      setInputMessage('');
    }
  };

  // キー入力のたびにメッセージのテキストを入力するinput要素を更新する．
  const inputChanged = (event) => {
    setInputMessage(event.target.value);
  };

  // コンポーネントがマウントされた時にソケットにイベントリスナーをつける．
  useEffect(() => {
    if (socket) {
      console.log('[TextChat] adding listeners');
      // イベントリスナーを付加する．
      socket.on('text', handleTextMessage);
      return () => {
        console.log('[TextChat] removing listeners');
        // イベントリスナーを削除する．
        socket.off('text', handleTextMessage);
      };
    }
  }, []);

  /* ここまで */

  return (
    /* CSSを使う時はclassName属性を追加してCSSクラスを設定してください．*/
    <div>
      {/* ここから */}
      { /* メッセージの履歴の表示 */}
      <div>{messages.map((message) => (
        <div key={message.from + message.time}>
          {message.from} &gt; {message.text}
        </div>))}
      </div>
      {/* メッセージの入力 */}
      <div>
        <input type="text" onChange={inputChanged} value={inputMessage} />
        <button type="button" onClick={sendTextMessage}
          disabled={socket === null || inputMessage === ""}>
          送信
        </button>
      </div>



      {/* ここまで */}
    </div >
  );
}
