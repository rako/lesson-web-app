/**
 * Reactコンポーネントの例
 */
export const Hello = () => {
  return (
    <div>
      <p>Hello! </p>
    </div>
  );
};
