/**
 * カウンターの例
 */
import { useState } from 'react';

// 関数の引数としてprops の代わりに分割代入を使うことも考えられる．
export const Counter = (props)=> {
  /* ここから */





  /* ここまで */

  return (
    <div>
      {/* ここから */}





      {/* ここまで */}
    </div>
  );
}
