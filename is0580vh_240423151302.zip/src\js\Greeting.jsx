/**
 * Reactコンポーネントの例
 */
// nameのデフォルト値を設定するようにしても構わない．
export const Greeting = ({ name }) => {
  /* ここから */





  /* ここまで */
};
